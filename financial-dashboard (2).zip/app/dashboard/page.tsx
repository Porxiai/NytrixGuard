import Dashboard from "@/components/kokonutui/dashboard"

export default function DashboardPage() {
  return <Dashboard />
}
