const DEEPSEEK_API_KEY = "sk-383485b263d247e2a19d6a583cdc1f04"

export async function POST(req: Request) {
  const { messages } = await req.json()

  if (!messages || !Array.isArray(messages) || messages.length === 0) {
    return Response.json({ error: "Messages array is required" }, { status: 400 })
  }

  try {
    const response = await fetch("https://api.deepseek.com/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${DEEPSEEK_API_KEY}`,
      },
      body: JSON.stringify({
        model: "deepseek-chat",
        messages: messages,
        max_tokens: 1000,
      }),
    })

    if (!response.ok) {
      const errorData = await response.text()
      console.error("DeepSeek API Error:", errorData)
      return Response.json({ error: "Failed to get response from AI" }, { status: 500 })
    }

    const data = await response.json()
    const content = data.choices?.[0]?.message?.content || "No response generated"

    return Response.json({ content })
  } catch (error) {
    console.error("AI Error:", error)
    return Response.json({ error: "Sorry, I encountered an error processing your request." }, { status: 500 })
  }
}
