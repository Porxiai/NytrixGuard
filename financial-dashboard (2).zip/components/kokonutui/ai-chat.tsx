"use client"
import { useState, useRef, useEffect, type FormEvent } from "react"
import { Bot, Send, User, Loader2, Sparkles, Copy, Check, Trash2, Wand2, Zap, Shield, Code2 } from "lucide-react"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

const quickPrompts = [
  { icon: Shield, label: "Security tips", prompt: "What are some best practices for API security?" },
  { icon: Code2, label: "Code help", prompt: "Help me write a secure authentication flow" },
  { icon: Zap, label: "Optimize", prompt: "How can I optimize my checkpoint performance?" },
]

export default function AIChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content:
        "Hello! I'm NytrixAi, your intelligent security assistant. I can help you with:\n\n• Security best practices\n• API key management\n• Script debugging\n• Performance optimization\n\nHow can I assist you today?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const copyToClipboard = async (text: string, id: string) => {
    await navigator.clipboard.writeText(text)
    setCopiedId(id)
    setTimeout(() => setCopiedId(null), 2000)
  }

  const clearChat = () => {
    setMessages([
      {
        id: Date.now().toString(),
        role: "assistant",
        content: "Chat cleared. How can I help you?",
        timestamp: new Date(),
      },
    ])
  }

  const handleQuickPrompt = (prompt: string) => {
    setInput(prompt)
    inputRef.current?.focus()
  }

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isLoading) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMessage].map((m) => ({
            role: m.role,
            content: m.content,
          })),
        }),
      })

      if (!response.ok) throw new Error("Failed to get response")

      const data = await response.json()

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: data.content || "Sorry, I couldn't generate a response.",
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      console.error("Chat error:", error)
      setMessages((prev) => [
        ...prev,
        {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: "Sorry, something went wrong. Please try again.",
          timestamp: new Date(),
        },
      ])
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] animate-fade-in">
      <div className="flex gap-4 h-full">
        {/* Main Chat Area */}
        <div className="flex-1 bg-neutral-950 rounded-2xl border border-white/[0.06] flex flex-col overflow-hidden">
          {/* Header */}
          <div className="px-5 py-4 border-b border-white/[0.06] flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-violet-500/20 to-purple-600/20 flex items-center justify-center">
                <Sparkles className="h-5 w-5 text-violet-400" />
              </div>
              <div>
                <h2 className="text-base font-semibold text-white">NytrixAi</h2>
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-xs text-neutral-500">Powered by DeepSeek</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={clearChat}
                className="p-2 rounded-lg hover:bg-white/5 border border-white/[0.06] transition-colors group"
                title="Clear chat"
              >
                <Trash2 className="h-4 w-4 text-neutral-500 group-hover:text-red-400 transition-colors" />
              </button>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4 custom-scrollbar">
            {messages.map((message) => (
              <div key={message.id} className={`flex gap-3 ${message.role === "user" ? "flex-row-reverse" : ""}`}>
                <div
                  className={`flex-shrink-0 w-9 h-9 rounded-xl flex items-center justify-center ${
                    message.role === "user"
                      ? "bg-gradient-to-br from-blue-500/20 to-cyan-500/20"
                      : "bg-gradient-to-br from-violet-500/20 to-purple-500/20"
                  }`}
                >
                  {message.role === "user" ? (
                    <User className="h-4 w-4 text-blue-400" />
                  ) : (
                    <Bot className="h-4 w-4 text-violet-400" />
                  )}
                </div>
                <div className="flex flex-col gap-1 max-w-[80%]">
                  <div
                    className={`relative group px-4 py-3 rounded-2xl ${
                      message.role === "user"
                        ? "bg-gradient-to-br from-blue-600 to-blue-700 text-white rounded-tr-md"
                        : "bg-white/[0.04] border border-white/[0.06] text-white rounded-tl-md"
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap leading-relaxed">{message.content}</p>
                    {message.role === "assistant" && (
                      <button
                        onClick={() => copyToClipboard(message.content, message.id)}
                        className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-1.5 rounded-lg bg-white/10 hover:bg-white/20 transition-all"
                      >
                        {copiedId === message.id ? (
                          <Check className="h-3 w-3 text-emerald-400" />
                        ) : (
                          <Copy className="h-3 w-3 text-neutral-400" />
                        )}
                      </button>
                    )}
                  </div>
                  <span className={`text-[10px] text-neutral-600 ${message.role === "user" ? "text-right" : ""}`}>
                    {message.timestamp.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}
                  </span>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex gap-3">
                <div className="flex-shrink-0 w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500/20 to-purple-500/20 flex items-center justify-center">
                  <Bot className="h-4 w-4 text-violet-400" />
                </div>
                <div className="px-4 py-3 rounded-2xl rounded-tl-md bg-white/[0.04] border border-white/[0.06]">
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-4 w-4 animate-spin text-violet-400" />
                    <span className="text-sm text-neutral-400">Thinking...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 border-t border-white/[0.06]">
            {/* Quick Prompts */}
            <div className="flex gap-2 mb-3 overflow-x-auto pb-2 custom-scrollbar">
              {quickPrompts.map((item, index) => (
                <button
                  key={index}
                  onClick={() => handleQuickPrompt(item.prompt)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.06] text-xs text-neutral-400 hover:text-white transition-all whitespace-nowrap"
                >
                  <item.icon className="h-3 w-3" />
                  {item.label}
                </button>
              ))}
            </div>

            <form onSubmit={handleSubmit} className="flex gap-3">
              <div className="flex-1 relative">
                <input
                  ref={inputRef}
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask NytrixAi anything..."
                  disabled={isLoading}
                  className="w-full px-4 py-3.5 rounded-xl border border-white/[0.08] bg-white/[0.03] text-white placeholder-neutral-500 focus:outline-none focus:border-violet-500/50 focus:ring-1 focus:ring-violet-500/20 disabled:opacity-50 text-sm transition-all"
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 text-[10px] text-neutral-600 hidden sm:block">
                  Press Enter ↵
                </div>
              </div>
              <button
                type="submit"
                disabled={isLoading || !input.trim()}
                className="px-5 py-3.5 rounded-xl bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-500 hover:to-purple-500 text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-violet-500/20"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>

        {/* Side Panel - Hidden on mobile */}
        <div className="hidden xl:flex flex-col w-72 gap-4">
          {/* AI Stats */}
          <div className="bg-neutral-950 rounded-2xl border border-white/[0.06] p-4">
            <h3 className="text-sm font-medium text-white mb-4">Session Stats</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs text-neutral-500">Messages</span>
                <span className="text-sm font-medium text-white">{messages.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs text-neutral-500">Tokens Used</span>
                <span className="text-sm font-medium text-white">
                  ~{messages.reduce((acc, m) => acc + m.content.length, 0)}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs text-neutral-500">Response Time</span>
                <span className="text-sm font-medium text-emerald-400">~1.2s</span>
              </div>
            </div>
          </div>

          {/* Capabilities */}
          <div className="bg-neutral-950 rounded-2xl border border-white/[0.06] p-4 flex-1">
            <h3 className="text-sm font-medium text-white mb-4">Capabilities</h3>
            <div className="space-y-3">
              {[
                { icon: Shield, label: "Security Analysis", color: "text-emerald-400" },
                { icon: Code2, label: "Code Generation", color: "text-blue-400" },
                { icon: Wand2, label: "Smart Suggestions", color: "text-violet-400" },
                { icon: Zap, label: "Performance Tips", color: "text-orange-400" },
              ].map((item, index) => (
                <div key={index} className="flex items-center gap-3 p-2 rounded-lg bg-white/[0.02]">
                  <item.icon className={`h-4 w-4 ${item.color}`} />
                  <span className="text-xs text-neutral-400">{item.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
