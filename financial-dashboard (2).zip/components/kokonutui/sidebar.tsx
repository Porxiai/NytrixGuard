"use client"

import type React from "react"
import {
  Key,
  Search,
  Users2,
  Shield,
  MessagesSquare,
  Video,
  Settings,
  HelpCircle,
  Menu,
  Sparkles,
  Home,
  Command,
  X,
  GitBranch,
  FolderKanban,
} from "lucide-react"

import { useState } from "react"
import { useNav } from "./layout"

export default function Sidebar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const { activeTab, setActiveTab } = useNav()

  function handleNavigation(tab: string) {
    setActiveTab(tab)
    setIsMobileMenuOpen(false)
  }

  function NavItem({
    tab,
    icon: Icon,
    children,
  }: {
    tab: string
    icon: React.ElementType
    children: React.ReactNode
  }) {
    const isActive = activeTab === tab
    return (
      <button
        onClick={() => handleNavigation(tab)}
        className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm rounded-lg transition-all duration-200 ${
          isActive ? "bg-white/10 text-white font-medium" : "text-neutral-400 hover:text-white hover:bg-white/5"
        }`}
      >
        <Icon className={`h-4 w-4 flex-shrink-0 ${isActive ? "text-white" : ""}`} />
        <span className="truncate">{children}</span>
        {isActive && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-white" />}
      </button>
    )
  }

  return (
    <>
      {/* Mobile menu button */}
      <button
        type="button"
        className="lg:hidden fixed top-4 left-4 z-[70] p-2.5 rounded-xl bg-black border border-white/10 shadow-lg"
        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
      >
        {isMobileMenuOpen ? <X className="h-5 w-5 text-white" /> : <Menu className="h-5 w-5 text-white" />}
      </button>

      <nav
        className={`
          fixed inset-y-0 left-0 z-[70] w-64 bg-black transform transition-transform duration-200 ease-in-out
          lg:translate-x-0 lg:static lg:w-64 border-r border-white/[0.08]
          ${isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"}
        `}
      >
        <div className="h-full flex flex-col">
          {/* Logo */}
          <div className="h-14 px-4 flex items-center border-b border-white/[0.08]">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-white to-neutral-300 flex items-center justify-center shadow-lg">
                <Shield className="h-4 w-4 text-black" />
              </div>
              <span className="text-sm font-bold text-white tracking-tight">NytrixGuard</span>
            </div>
          </div>

          {/* Search */}
          <div className="p-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/[0.03] border border-white/[0.08] rounded-lg pl-9 pr-12 py-2.5 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-white/20 focus:bg-white/[0.05] transition-all"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-0.5 px-1.5 py-1 rounded-md bg-white/5 border border-white/10">
                <Command className="h-3 w-3 text-neutral-500" />
                <span className="text-[10px] text-neutral-500 font-medium">K</span>
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto px-3 custom-scrollbar">
            <div className="space-y-6 pb-4">
              {/* AI Section */}
              <div>
                <div className="px-3 mb-2 text-[10px] font-semibold uppercase tracking-widest text-neutral-600">
                  AI Assistant
                </div>
                <NavItem tab="nytrixai" icon={Sparkles}>
                  NytrixAi
                </NavItem>
              </div>

              {/* Main */}
              <div>
                <div className="px-3 mb-2 text-[10px] font-semibold uppercase tracking-widest text-neutral-600">
                  Overview
                </div>
                <div className="space-y-1">
                  <NavItem tab="home" icon={Home}>
                    Home
                  </NavItem>
                </div>
              </div>

              <div>
                <div className="px-3 mb-2 text-[10px] font-semibold uppercase tracking-widest text-neutral-600">
                  Repository
                </div>
                <div className="space-y-1">
                  <NavItem tab="projects" icon={FolderKanban}>
                    Projects
                  </NavItem>
                  <NavItem tab="credentials" icon={Key}>
                    Credentials
                  </NavItem>
                  <NavItem tab="interrogations" icon={GitBranch}>
                    Interrogations
                  </NavItem>
                </div>
              </div>

              {/* Team */}
              <div>
                <div className="px-3 mb-2 text-[10px] font-semibold uppercase tracking-widest text-neutral-600">
                  Team
                </div>
                <div className="space-y-1">
                  <NavItem tab="members" icon={Users2}>
                    Members
                  </NavItem>
                  <NavItem tab="permissions" icon={Shield}>
                    Permissions
                  </NavItem>
                  <NavItem tab="chat" icon={MessagesSquare}>
                    Chat
                  </NavItem>
                  <NavItem tab="meetings" icon={Video}>
                    Meetings
                  </NavItem>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom section */}
          <div className="px-3 py-3 border-t border-white/[0.08]">
            <div className="space-y-1">
              <NavItem tab="settings" icon={Settings}>
                Settings
              </NavItem>
              <NavItem tab="help" icon={HelpCircle}>
                Help Center
              </NavItem>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile overlay */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[65] lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
    </>
  )
}
