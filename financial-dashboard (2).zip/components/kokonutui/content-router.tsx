"use client"

import { useNav } from "./layout"
import Content from "./content"
import AIChat from "./ai-chat"
import PlaceholderPage from "./placeholder-page"
import CredentialsPage from "./credentials-page"

export default function ContentRouter() {
  const { activeTab } = useNav()

  switch (activeTab) {
    case "home":
      return <Content />
    case "nytrixai":
      return <AIChat />
    case "credentials":
      return <CredentialsPage />
    default:
      return <PlaceholderPage tab={activeTab} />
  }
}
