"use client"

import { useState } from "react"
import {
  Key,
  Download,
  Plus,
  Search,
  X,
  Filter,
  ArrowUpDown,
  ChevronDown,
  ChevronUp,
  CheckCircle2,
  XCircle,
  Clock,
  Settings,
  Trash2,
  LayoutGrid,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Shield,
  Copy,
  MoreHorizontal,
  Eye,
  EyeOff,
} from "lucide-react"

type KeyStatus = "active" | "expired" | "revoked"

interface CredentialKey {
  id: string
  name: string
  key: string
  status: KeyStatus
  created: string
  expires: string
  lastUsed: string
  usageCount: number
  isPremium: boolean
}

const sampleKeys: CredentialKey[] = [
  {
    id: "1",
    name: "Production API Key",
    key: "ntx_prod_a1b2c3d4e5f6g7h8i9j0",
    status: "active",
    created: "2024-01-15",
    expires: "2025-01-15",
    lastUsed: "2 hours ago",
    usageCount: 1250,
    isPremium: true,
  },
  {
    id: "2",
    name: "Development Key",
    key: "ntx_dev_k1l2m3n4o5p6q7r8s9t0",
    status: "active",
    created: "2024-02-20",
    expires: "2025-02-20",
    lastUsed: "5 mins ago",
    usageCount: 856,
    isPremium: false,
  },
  {
    id: "3",
    name: "Testing Environment",
    key: "ntx_test_u1v2w3x4y5z6a7b8c9d0",
    status: "expired",
    created: "2023-06-10",
    expires: "2024-06-10",
    lastUsed: "6 months ago",
    usageCount: 432,
    isPremium: false,
  },
  {
    id: "4",
    name: "Staging API",
    key: "ntx_stage_e1f2g3h4i5j6k7l8m9n0",
    status: "active",
    created: "2024-03-01",
    expires: "2025-03-01",
    lastUsed: "1 day ago",
    usageCount: 234,
    isPremium: true,
  },
  {
    id: "5",
    name: "Legacy System Key",
    key: "ntx_legacy_o1p2q3r4s5t6u7v8w9x0",
    status: "revoked",
    created: "2022-11-05",
    expires: "2023-11-05",
    lastUsed: "1 year ago",
    usageCount: 89,
    isPremium: false,
  },
]

export default function CredentialsPage() {
  const [activeTab, setActiveTab] = useState<"keys" | "premium">("keys")
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState<KeyStatus | "all">("all")
  const [sortBy, setSortBy] = useState<"expires" | "created" | "usage">("expires")
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("asc")
  const [currentPage, setCurrentPage] = useState(1)
  const [selectedKeys, setSelectedKeys] = useState<string[]>([])
  const [showKey, setShowKey] = useState<string | null>(null)
  const [isSelectMode, setIsSelectMode] = useState(false)

  const filteredKeys = sampleKeys
    .filter((key) => {
      if (activeTab === "premium" && !key.isPremium) return false
      if (activeTab === "keys" && key.isPremium) return false
      if (statusFilter !== "all" && key.status !== statusFilter) return false
      if (searchQuery && !key.name.toLowerCase().includes(searchQuery.toLowerCase())) return false
      return true
    })
    .sort((a, b) => {
      const order = sortOrder === "asc" ? 1 : -1
      if (sortBy === "expires") return (new Date(a.expires).getTime() - new Date(b.expires).getTime()) * order
      if (sortBy === "created") return (new Date(a.created).getTime() - new Date(b.created).getTime()) * order
      return (a.usageCount - b.usageCount) * order
    })

  const totalKeys = filteredKeys.length
  const itemsPerPage = 5
  const totalPages = Math.ceil(totalKeys / itemsPerPage)
  const paginatedKeys = filteredKeys.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  const StatusBadge = ({ status }: { status: KeyStatus }) => {
    const config = {
      active: { icon: CheckCircle2, color: "text-emerald-400 bg-emerald-500/10", label: "Active" },
      expired: { icon: Clock, color: "text-orange-400 bg-orange-500/10", label: "Expired" },
      revoked: { icon: XCircle, color: "text-red-400 bg-red-500/10", label: "Revoked" },
    }
    const { icon: Icon, color, label } = config[status]
    return (
      <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${color}`}>
        <Icon className="w-3.5 h-3.5" />
        {label}
      </div>
    )
  }

  const toggleKeySelection = (id: string) => {
    setSelectedKeys((prev) => (prev.includes(id) ? prev.filter((k) => k !== id) : [...prev, id]))
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-6">
        <div className="flex items-start gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border border-blue-500/20 flex items-center justify-center">
            <Key className="h-7 w-7 text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Credentials</h1>
            <p className="text-neutral-400 text-sm mt-1">{totalKeys} Keys · My Keys</p>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm text-neutral-300 bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.08] rounded-xl transition-colors">
            <Download className="h-4 w-4" />
            Export
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm text-neutral-300 bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.08] rounded-xl transition-colors">
            <LayoutGrid className="h-4 w-4" />
            Batch create
          </button>
          <button className="flex items-center gap-2 px-4 py-2.5 text-sm text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors shadow-lg shadow-blue-500/20">
            <Plus className="h-4 w-4" />
            Create key
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex bg-white/[0.03] rounded-xl p-1 border border-white/[0.06] w-fit">
        <button
          onClick={() => setActiveTab("keys")}
          className={`px-6 py-2.5 text-sm font-medium rounded-lg transition-all duration-200 ${
            activeTab === "keys" ? "bg-white text-black" : "text-neutral-400 hover:text-white"
          }`}
        >
          Keys
        </button>
        <button
          onClick={() => setActiveTab("premium")}
          className={`px-6 py-2.5 text-sm font-medium rounded-lg transition-all duration-200 flex items-center gap-2 ${
            activeTab === "premium" ? "bg-white text-black" : "text-neutral-400 hover:text-white"
          }`}
        >
          <Sparkles className="h-3.5 w-3.5" />
          Premium Keys
        </button>
      </div>

      {/* Search and Filters */}
      <div className="bg-neutral-950 rounded-2xl p-5 border border-white/[0.06] space-y-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
          <input
            type="text"
            placeholder="Search keys..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white/[0.03] border border-white/[0.08] rounded-xl pl-11 pr-10 py-3 text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-white/20 focus:bg-white/[0.05] transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-500 hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Filters Row */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-neutral-500" />
            <span className="text-sm text-neutral-400">Status</span>
          </div>

          {/* Status filters */}
          <div className="flex items-center gap-2">
            {(["all", "active", "expired", "revoked"] as const).map((status) => (
              <button
                key={status}
                onClick={() => setStatusFilter(status)}
                className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${
                  statusFilter === status
                    ? "bg-blue-500/20 border border-blue-500/40"
                    : "bg-white/[0.03] border border-white/[0.08] hover:bg-white/[0.06]"
                }`}
              >
                {status === "all" && <LayoutGrid className="h-3.5 w-3.5 text-neutral-400" />}
                {status === "active" && <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />}
                {status === "expired" && <Clock className="h-3.5 w-3.5 text-orange-400" />}
                {status === "revoked" && <XCircle className="h-3.5 w-3.5 text-red-400" />}
              </button>
            ))}
          </div>

          <div className="w-px h-6 bg-white/[0.08]" />

          {/* Sort */}
          <div className="flex items-center gap-2">
            <ArrowUpDown className="h-4 w-4 text-neutral-500" />
            <span className="text-sm text-neutral-400">Sort</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSortBy("expires")}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all flex items-center gap-1.5 ${
                sortBy === "expires"
                  ? "bg-white/10 text-white border border-white/20"
                  : "text-neutral-400 hover:text-white bg-white/[0.03] border border-white/[0.08]"
              }`}
            >
              Expires
              {sortBy === "expires" && (
                <button onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}>
                  {sortOrder === "asc" ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                </button>
              )}
            </button>
            <button
              onClick={() => setSortBy("created")}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-all ${
                sortBy === "created"
                  ? "bg-white/10 text-white border border-white/20"
                  : "text-neutral-400 hover:text-white bg-white/[0.03] border border-white/[0.08]"
              }`}
            >
              Created
            </button>
          </div>
        </div>

        {/* Action Bar */}
        <div className="flex items-center justify-between pt-2 border-t border-white/[0.06]">
          <div className="flex items-center gap-4">
            <button
              onClick={() => {
                setSearchQuery("")
                setStatusFilter("all")
              }}
              className="flex items-center gap-2 text-sm text-neutral-400 hover:text-white transition-colors"
            >
              <X className="h-4 w-4" />
              Clear
            </button>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsSelectMode(!isSelectMode)}
              className={`flex items-center gap-2 text-sm transition-colors ${
                isSelectMode ? "text-blue-400" : "text-neutral-400 hover:text-white"
              }`}
            >
              <LayoutGrid className="h-4 w-4" />
              Select mode
            </button>
            <button className="flex items-center gap-2 text-sm text-neutral-400 hover:text-white transition-colors">
              <Settings className="h-4 w-4" />
              Settings
            </button>
            <button className="flex items-center gap-2 text-sm text-red-400 hover:text-red-300 transition-colors">
              <Trash2 className="h-4 w-4" />
              Delete expired
            </button>
          </div>
        </div>
      </div>

      {/* Keys List */}
      {paginatedKeys.length > 0 ? (
        <div className="space-y-3">
          {paginatedKeys.map((key) => (
            <div
              key={key.id}
              className={`group bg-neutral-950 rounded-xl p-4 border transition-all duration-200 ${
                selectedKeys.includes(key.id)
                  ? "border-blue-500/40 bg-blue-500/5"
                  : "border-white/[0.06] hover:border-white/[0.12]"
              }`}
            >
              <div className="flex items-center gap-4">
                {isSelectMode && (
                  <button
                    onClick={() => toggleKeySelection(key.id)}
                    className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-colors ${
                      selectedKeys.includes(key.id)
                        ? "bg-blue-500 border-blue-500"
                        : "border-white/20 hover:border-white/40"
                    }`}
                  >
                    {selectedKeys.includes(key.id) && <CheckCircle2 className="h-3 w-3 text-white" />}
                  </button>
                )}

                <div className="w-10 h-10 rounded-xl bg-white/[0.03] border border-white/[0.06] flex items-center justify-center">
                  {key.isPremium ? (
                    <Sparkles className="h-5 w-5 text-amber-400" />
                  ) : (
                    <Key className="h-5 w-5 text-neutral-400" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium text-white">{key.name}</span>
                    <StatusBadge status={key.status} />
                    {key.isPremium && (
                      <div className="flex items-center gap-1 px-2 py-0.5 bg-amber-500/10 rounded-full">
                        <Shield className="h-3 w-3 text-amber-400" />
                        <span className="text-[10px] font-medium text-amber-400">Premium</span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <code className="text-xs text-neutral-500 font-mono">
                      {showKey === key.id ? key.key : `${key.key.slice(0, 12)}${"•".repeat(16)}`}
                    </code>
                    <button
                      onClick={() => setShowKey(showKey === key.id ? null : key.id)}
                      className="text-neutral-500 hover:text-white transition-colors"
                    >
                      {showKey === key.id ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                    </button>
                    <button
                      onClick={() => copyToClipboard(key.key)}
                      className="text-neutral-500 hover:text-white transition-colors"
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

                <div className="hidden lg:flex items-center gap-8 text-xs text-neutral-500">
                  <div>
                    <span className="block text-neutral-600">Created</span>
                    <span className="text-neutral-400">{key.created}</span>
                  </div>
                  <div>
                    <span className="block text-neutral-600">Expires</span>
                    <span className="text-neutral-400">{key.expires}</span>
                  </div>
                  <div>
                    <span className="block text-neutral-600">Last used</span>
                    <span className="text-neutral-400">{key.lastUsed}</span>
                  </div>
                  <div>
                    <span className="block text-neutral-600">Usage</span>
                    <span className="text-white font-medium">{key.usageCount.toLocaleString()}</span>
                  </div>
                </div>

                <button className="opacity-0 group-hover:opacity-100 p-2 hover:bg-white/5 rounded-lg transition-all">
                  <MoreHorizontal className="h-4 w-4 text-neutral-400" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="flex flex-col items-center justify-center py-20 animate-fade-in">
          <div className="w-20 h-20 rounded-2xl bg-white/[0.03] border border-white/[0.06] flex items-center justify-center mb-6">
            <Key className="h-9 w-9 text-neutral-500" />
          </div>
          <h2 className="text-lg font-semibold text-white mb-2">No keys for current search/filter.</h2>
          <p className="text-neutral-500 text-sm text-center max-w-sm mb-6">
            Try changing the filter or create a new key.
          </p>
          <div className="flex items-center gap-3">
            <button className="flex items-center gap-2 px-5 py-2.5 text-sm text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-colors shadow-lg shadow-blue-500/20">
              <Plus className="h-4 w-4" />
              Create key
            </button>
            <button
              onClick={() => {
                setSearchQuery("")
                setStatusFilter("all")
              }}
              className="flex items-center gap-2 px-5 py-2.5 text-sm text-neutral-300 bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.08] rounded-xl transition-colors"
            >
              Show all keys
            </button>
          </div>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 0 && (
        <div className="flex items-center justify-between pt-4">
          <button
            onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
            disabled={currentPage === 1}
            className="flex items-center gap-2 px-4 py-2 text-sm text-neutral-400 bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.08] rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="h-4 w-4" />
            Back
          </button>

          <div className="flex items-center gap-2 px-4 py-2 bg-white/[0.03] border border-white/[0.08] rounded-xl">
            <span className="text-sm text-neutral-400">page</span>
            <span className="text-sm text-white font-semibold">{currentPage}</span>
            <span className="text-sm text-neutral-400">of</span>
            <span className="text-sm text-white font-semibold">{totalPages}</span>
          </div>

          <button
            onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
            disabled={currentPage === totalPages}
            className="flex items-center gap-2 px-4 py-2 text-sm text-neutral-400 bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.08] rounded-xl transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Next
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      )}
    </div>
  )
}
