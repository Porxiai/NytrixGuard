"use client"

import type React from "react"
import { useState, useEffect } from "react"
import {
  MousePointerClick,
  CheckCircle2,
  Key,
  ListOrdered,
  CheckSquare,
  FileCode2,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  Globe,
  Server,
  ArrowRight,
  Zap,
  Activity,
  BarChart3,
  Sparkles,
  Sun,
  Moon,
  Sunrise,
  Sunset,
  TrendingUp,
} from "lucide-react"
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from "recharts"

const chartData = [
  { date: "Oct 27", clicks: 120, checkpoints: 80, keys: 50 },
  { date: "Oct 31", clicks: 190, checkpoints: 120, keys: 80 },
  { date: "Nov 04", clicks: 150, checkpoints: 100, keys: 120 },
  { date: "Nov 08", clicks: 250, checkpoints: 180, keys: 150 },
  { date: "Nov 12", clicks: 320, checkpoints: 240, keys: 200 },
  { date: "Nov 16", clicks: 280, checkpoints: 220, keys: 180 },
  { date: "Nov 20", clicks: 350, checkpoints: 280, keys: 250 },
  { date: "Nov 24", clicks: 420, checkpoints: 350, keys: 300 },
]

const activityData = [
  { time: "00:00", requests: 20, responses: 18 },
  { time: "04:00", requests: 35, responses: 32 },
  { time: "08:00", requests: 85, responses: 80 },
  { time: "12:00", requests: 120, responses: 115 },
  { time: "16:00", requests: 95, responses: 90 },
  { time: "20:00", requests: 60, responses: 55 },
  { time: "23:59", requests: 30, responses: 28 },
]

interface StatCardProps {
  icon: React.ReactNode
  label: string
  value: string | number
  subValue?: string
  change: string
  changeType: "up" | "down" | "neutral"
  accentColor: string
  showProgress?: boolean
  progressValue?: number
}

function StatCard({
  icon,
  label,
  value,
  subValue,
  change,
  changeType,
  accentColor,
  showProgress,
  progressValue,
}: StatCardProps) {
  return (
    <div className="group relative bg-neutral-950 rounded-xl p-5 border border-white/[0.06] hover:border-white/[0.12] transition-all duration-300 hover:shadow-lg hover:shadow-black/20">
      <div className="flex items-start justify-between mb-4">
        <div
          className={`w-11 h-11 rounded-xl flex items-center justify-center ${accentColor} transition-transform duration-300 group-hover:scale-110`}
        >
          {icon}
        </div>
        <div
          className={`flex items-center gap-1 text-xs font-medium px-2 py-1 rounded-full ${
            changeType === "up"
              ? "text-emerald-400 bg-emerald-500/10"
              : changeType === "down"
                ? "text-red-400 bg-red-500/10"
                : "text-neutral-500 bg-white/5"
          }`}
        >
          {changeType === "up" && <ArrowUpRight className="w-3 h-3" />}
          {changeType === "down" && <ArrowDownRight className="w-3 h-3" />}
          {change}
        </div>
      </div>

      <div className="space-y-1">
        <p className="text-sm text-neutral-500">{label}</p>
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-bold text-white tracking-tight">{value}</span>
          {subValue && <span className="text-sm text-neutral-500">{subValue}</span>}
        </div>
      </div>

      {showProgress && (
        <div className="mt-4 space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-neutral-500">Usage rate</span>
            <span className="text-white font-medium">{progressValue}%</span>
          </div>
          <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-500 to-cyan-400 rounded-full transition-all duration-500"
              style={{ width: `${progressValue}%` }}
            />
          </div>
        </div>
      )}

      {!showProgress && (
        <div className="mt-4 h-10 flex items-end gap-[3px]">
          {[35, 55, 40, 65, 50, 75, 55, 70, 45, 60, 80, 65].map((h, i) => (
            <div
              key={i}
              className="flex-1 bg-white/10 group-hover:bg-white/20 rounded-sm transition-all duration-300"
              style={{ height: `${h}%` }}
            />
          ))}
        </div>
      )}
    </div>
  )
}

function QuickAction({
  icon: Icon,
  label,
  description,
  color,
}: { icon: React.ElementType; label: string; description: string; color: string }) {
  return (
    <button className="flex items-start gap-4 p-4 bg-neutral-950 rounded-xl border border-white/[0.06] hover:border-white/[0.12] hover:bg-neutral-900/50 transition-all duration-200 text-left group w-full">
      <div
        className={`w-11 h-11 rounded-xl ${color} flex items-center justify-center flex-shrink-0 transition-transform duration-300 group-hover:scale-110`}
      >
        <Icon className="h-5 w-5 text-white" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-white">{label}</span>
          <ArrowRight className="h-3.5 w-3.5 text-neutral-500 group-hover:text-white group-hover:translate-x-0.5 transition-all" />
        </div>
        <p className="text-xs text-neutral-500 mt-0.5">{description}</p>
      </div>
    </button>
  )
}

function getGreetingData(): { greeting: string; icon: React.ElementType; message: string; gradient: string } {
  const hour = new Date().getHours()
  if (hour >= 5 && hour < 12) {
    return {
      greeting: "Good morning",
      icon: Sunrise,
      message: "Start your day with a quick overview of your projects",
      gradient: "from-orange-500 to-amber-500",
    }
  }
  if (hour >= 12 && hour < 17) {
    return {
      greeting: "Good afternoon",
      icon: Sun,
      message: "Stay productive! Here's your dashboard status",
      gradient: "from-yellow-500 to-orange-500",
    }
  }
  if (hour >= 17 && hour < 21) {
    return {
      greeting: "Good evening",
      icon: Sunset,
      message: "Wrapping up? Check your daily progress below",
      gradient: "from-purple-500 to-pink-500",
    }
  }
  return {
    greeting: "Good night",
    icon: Moon,
    message: "Working late? Here's a quick summary of your system",
    gradient: "from-indigo-500 to-purple-500",
  }
}

export default function Content() {
  const [timeRange, setTimeRange] = useState<"7D" | "14D" | "30D">("30D")
  const [greetingData, setGreetingData] = useState(getGreetingData())
  const [currentTime, setCurrentTime] = useState("")
  const [currentDate, setCurrentDate] = useState("")

  useEffect(() => {
    setGreetingData(getGreetingData())
    const updateTime = () => {
      const now = new Date()
      setCurrentTime(now.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }))
      setCurrentDate(now.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" }))
    }
    updateTime()
    const interval = setInterval(updateTime, 60000)
    return () => clearInterval(interval)
  }, [])

  const GreetingIcon = greetingData.icon

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="relative overflow-hidden bg-gradient-to-br from-neutral-950 via-neutral-900/50 to-neutral-950 rounded-2xl p-6 border border-white/[0.06]">
        {/* Background decorations */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-blue-500/5 to-violet-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-gradient-to-tr from-emerald-500/5 to-cyan-500/5 rounded-full blur-3xl" />

        <div className="relative flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div className="flex items-start gap-4">
            <div
              className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${greetingData.gradient} flex items-center justify-center shadow-lg shadow-${greetingData.gradient.split("-")[1]}-500/20`}
            >
              <GreetingIcon className="h-8 w-8 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-3 mb-1">
                <h1 className="text-2xl font-bold text-white">{greetingData.greeting}, Anonymous</h1>
                <div className="flex items-center gap-1 px-2 py-1 bg-emerald-500/10 rounded-full">
                  <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />
                  <span className="text-[10px] font-medium text-emerald-400 uppercase tracking-wider">Online</span>
                </div>
              </div>
              <p className="text-neutral-400 text-sm">{greetingData.message}</p>
              <div className="flex items-center gap-4 mt-3">
                <div className="flex items-center gap-2 text-xs text-neutral-500">
                  <Clock className="h-3.5 w-3.5" />
                  <span>{currentTime}</span>
                </div>
                <div className="w-1 h-1 bg-neutral-700 rounded-full" />
                <span className="text-xs text-neutral-500">{currentDate}</span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Quick stats badges */}
            <div className="flex items-center gap-2 px-4 py-2.5 bg-white/[0.03] rounded-xl border border-white/[0.06] hover:bg-white/[0.05] transition-colors">
              <Globe className="h-4 w-4 text-blue-400" />
              <div className="text-left">
                <span className="text-xs text-neutral-500 block">Regions</span>
                <span className="text-sm text-white font-semibold">12 Active</span>
              </div>
            </div>
            <div className="flex items-center gap-2 px-4 py-2.5 bg-white/[0.03] rounded-xl border border-white/[0.06] hover:bg-white/[0.05] transition-colors">
              <Server className="h-4 w-4 text-emerald-400" />
              <div className="text-left">
                <span className="text-xs text-neutral-500 block">Uptime</span>
                <span className="text-sm text-white font-semibold">99.9%</span>
              </div>
            </div>
            <div className="flex items-center gap-2 px-4 py-2.5 bg-white/[0.03] rounded-xl border border-white/[0.06] hover:bg-white/[0.05] transition-colors">
              <TrendingUp className="h-4 w-4 text-violet-400" />
              <div className="text-left">
                <span className="text-xs text-neutral-500 block">Growth</span>
                <span className="text-sm text-white font-semibold">+24%</span>
              </div>
            </div>

            {/* Time range */}
            <div className="flex bg-black rounded-xl p-1 border border-white/[0.08]">
              {(["7D", "14D", "30D"] as const).map((range) => (
                <button
                  key={range}
                  onClick={() => setTimeRange(range)}
                  className={`px-4 py-2 text-xs font-medium rounded-lg transition-all duration-200 ${
                    timeRange === range ? "bg-white text-black" : "text-neutral-400 hover:text-white"
                  }`}
                >
                  {range}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <StatCard
          icon={<MousePointerClick className="w-5 h-5 text-blue-400" />}
          label="Total Clicks"
          value="1,234"
          change="+12.5%"
          changeType="up"
          accentColor="bg-blue-500/15"
        />
        <StatCard
          icon={<CheckCircle2 className="w-5 h-5 text-emerald-400" />}
          label="Checkpoints"
          value="856"
          change="+8.2%"
          changeType="up"
          accentColor="bg-emerald-500/15"
        />
        <StatCard
          icon={<Key className="w-5 h-5 text-orange-400" />}
          label="Active Keys"
          value="432"
          change="+5.1%"
          changeType="up"
          accentColor="bg-orange-500/15"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <StatCard
          icon={<ListOrdered className="w-5 h-5 text-violet-400" />}
          label="Keys Generated"
          value="2,451"
          change="+18.3%"
          changeType="up"
          accentColor="bg-violet-500/15"
        />
        <StatCard
          icon={<CheckSquare className="w-5 h-5 text-cyan-400" />}
          label="Keys Used"
          value="1,892"
          subValue="/ 2,451"
          change="+12.1%"
          changeType="up"
          accentColor="bg-cyan-500/15"
          showProgress
          progressValue={77}
        />
        <StatCard
          icon={<FileCode2 className="w-5 h-5 text-pink-400" />}
          label="Script Executions"
          value="567"
          subValue="(3 active)"
          change="+4.7%"
          changeType="up"
          accentColor="bg-pink-500/15"
        />
      </div>

      <div className="bg-neutral-950 rounded-2xl p-6 border border-white/[0.06]">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between mb-6 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-500/20 to-violet-500/20 flex items-center justify-center">
              <BarChart3 className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">Performance & Activity</h3>
              <p className="text-xs text-neutral-500">Real-time monitoring data</p>
            </div>
          </div>
          <div className="flex items-center gap-6 text-xs text-neutral-500">
            <span className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-blue-500" /> Clicks
            </span>
            <span className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-500" /> Checkpoints
            </span>
            <span className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-orange-500" /> Keys
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* Main Chart */}
          <div className="xl:col-span-2">
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
                  <defs>
                    <linearGradient id="clicksGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="checkGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="keysGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#f59e0b" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff08" vertical={false} />
                  <XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fill: "#737373", fontSize: 11 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: "#737373", fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#0a0a0a",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: "12px",
                      color: "#fff",
                      fontSize: "12px",
                      padding: "12px",
                    }}
                  />
                  <Area type="monotone" dataKey="clicks" stroke="#3b82f6" strokeWidth={2} fill="url(#clicksGrad)" />
                  <Area type="monotone" dataKey="checkpoints" stroke="#10b981" strokeWidth={2} fill="url(#checkGrad)" />
                  <Area type="monotone" dataKey="keys" stroke="#f59e0b" strokeWidth={2} fill="url(#keysGrad)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Activity Side Panel */}
          <div className="bg-white/[0.02] rounded-xl p-4 border border-white/[0.04]">
            <div className="flex items-center gap-2 mb-4">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span className="text-sm font-medium text-white">Today's Activity</span>
            </div>

            <div className="h-[140px] mb-4">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={activityData} margin={{ top: 5, right: 5, left: -25, bottom: 5 }}>
                  <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{ fill: "#737373", fontSize: 9 }} />
                  <YAxis hide />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#0a0a0a",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: "8px",
                      color: "#fff",
                      fontSize: "11px",
                    }}
                  />
                  <Bar dataKey="requests" fill="#06b6d4" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white/5 rounded-lg p-3">
                <div className="flex items-center gap-1.5 text-neutral-500 text-xs mb-1">
                  <Zap className="w-3 h-3" />
                  Peak Time
                </div>
                <p className="text-white text-lg font-semibold">12:00 PM</p>
              </div>
              <div className="bg-white/5 rounded-lg p-3">
                <div className="flex items-center gap-1.5 text-neutral-500 text-xs mb-1">
                  <Clock className="w-3 h-3" />
                  Avg Response
                </div>
                <p className="text-white text-lg font-semibold">2.4s</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-violet-400" />
          <h3 className="text-base font-semibold text-white">Quick Actions</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          <QuickAction
            icon={Key}
            label="Generate New Key"
            description="Create a new API key for your project"
            color="bg-gradient-to-br from-orange-500/20 to-amber-500/20"
          />
          <QuickAction
            icon={FileCode2}
            label="Deploy Script"
            description="Upload and deploy a new script"
            color="bg-gradient-to-br from-pink-500/20 to-rose-500/20"
          />
          <QuickAction
            icon={CheckCircle2}
            label="Add Checkpoint"
            description="Create a new verification checkpoint"
            color="bg-gradient-to-br from-emerald-500/20 to-teal-500/20"
          />
        </div>
      </div>
    </div>
  )
}
