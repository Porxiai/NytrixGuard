import ContentRouter from "./content-router"
import Layout from "./layout"

export default function Dashboard() {
  return (
    <Layout>
      <ContentRouter />
    </Layout>
  )
}
