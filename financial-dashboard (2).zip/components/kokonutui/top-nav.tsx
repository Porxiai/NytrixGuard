"use client"

import { DropdownMenu, DropdownMenuContent, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import Image from "next/image"
import { Bell, ChevronRight, Home, ChevronDown } from "lucide-react"
import Profile01 from "./profile-01"
import { ThemeToggle } from "../theme-toggle"
import { useNav } from "./layout"

export default function TopNav() {
  const { activeTab } = useNav()

  const tabLabels: Record<string, string> = {
    home: "Overview",
    nytrixai: "NytrixAi",
    projects: "Projects",
    transactions: "Transactions",
    invoices: "Invoices",
    payments: "Payments",
    members: "Members",
    permissions: "Permissions",
    chat: "Chat",
    meetings: "Meetings",
    settings: "Settings",
    help: "Help",
  }

  return (
    <nav className="px-4 sm:px-6 flex items-center justify-between bg-black border-b border-white/[0.08] h-full">
      {/* Breadcrumb */}
      <div className="font-medium text-sm hidden sm:flex items-center gap-1 text-neutral-400">
        <Home className="h-4 w-4" />
        <span className="ml-1.5">Home</span>
        <ChevronRight className="h-4 w-4 mx-1" />
        <span className="text-white">{tabLabels[activeTab] || activeTab}</span>
      </div>

      <div className="flex items-center gap-2 ml-auto">
        {/* Environment selector */}
        <button className="hidden md:flex items-center gap-2 px-3 py-1.5 text-sm text-neutral-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/[0.08] rounded-lg transition-colors">
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          <span>Production</span>
          <ChevronDown className="h-3.5 w-3.5" />
        </button>

        {/* Divider */}
        <div className="hidden md:block w-px h-5 bg-white/[0.08]" />

        {/* Notifications */}
        <button
          type="button"
          className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/[0.08] transition-colors relative"
        >
          <Bell className="h-4 w-4 text-neutral-400" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full border border-black" />
        </button>

        {/* Theme Toggle */}
        <ThemeToggle />

        {/* Divider */}
        <div className="w-px h-5 bg-white/[0.08]" />

        {/* User menu */}
        <DropdownMenu>
          <DropdownMenuTrigger className="focus:outline-none">
            <Image
              src="https://ferf1mheo22r9ira.public.blob.vercel-storage.com/avatar-01-n0x8HFv8EUetf9z6ht0wScJKoTHqf8.png"
              alt="User avatar"
              width={32}
              height={32}
              className="rounded-lg ring-1 ring-white/10 cursor-pointer hover:ring-white/20 transition-all"
            />
          </DropdownMenuTrigger>
          <DropdownMenuContent
            align="end"
            sideOffset={8}
            className="w-80 bg-black border-white/[0.08] rounded-lg shadow-2xl"
          >
            <Profile01 avatar="https://ferf1mheo22r9ira.public.blob.vercel-storage.com/avatar-01-n0x8HFv8EUetf9z6ht0wScJKoTHqf8.png" />
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </nav>
  )
}
