import type React from "react"
import {
  Folder,
  Users2,
  Shield,
  MessagesSquare,
  Video,
  Settings,
  HelpCircle,
  ArrowRight,
  GitBranch,
  FolderKanban,
  Key,
} from "lucide-react"

const icons: Record<string, React.ElementType> = {
  projects: FolderKanban,
  credentials: Key,
  interrogations: GitBranch,
  members: Users2,
  permissions: Shield,
  chat: MessagesSquare,
  meetings: Video,
  settings: Settings,
  help: HelpCircle,
}

const tabLabels: Record<string, string> = {
  projects: "Projects",
  credentials: "Credentials",
  interrogations: "Interrogations",
  members: "Members",
  permissions: "Permissions",
  chat: "Chat",
  meetings: "Meetings",
  settings: "Settings",
  help: "Help Center",
}

export default function PlaceholderPage({ tab }: { tab: string }) {
  const Icon = icons[tab] || Folder
  const label = tabLabels[tab] || tab

  return (
    <div className="flex flex-col items-center justify-center h-[calc(100vh-8rem)] animate-fade-in">
      <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/[0.06] flex items-center justify-center mb-6">
        <Icon className="h-7 w-7 text-neutral-400" />
      </div>
      <h2 className="text-xl font-semibold text-white mb-2">{label}</h2>
      <p className="text-neutral-500 text-sm text-center max-w-sm mb-6">
        This section is coming soon. We're working hard to bring you new features.
      </p>
      <button className="flex items-center gap-2 px-4 py-2 text-sm text-neutral-400 hover:text-white bg-white/5 hover:bg-white/10 border border-white/[0.06] rounded-lg transition-colors">
        Learn more
        <ArrowRight className="h-4 w-4" />
      </button>
    </div>
  )
}
