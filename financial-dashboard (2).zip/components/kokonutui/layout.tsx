"use client"

import type { ReactNode } from "react"
import Sidebar from "./sidebar"
import TopNav from "./top-nav"
import { useTheme } from "next-themes"
import { useEffect, useState, createContext, useContext } from "react"

type NavContextType = {
  activeTab: string
  setActiveTab: (tab: string) => void
}

export const NavContext = createContext<NavContextType>({
  activeTab: "home",
  setActiveTab: () => {},
})

export const useNav = () => useContext(NavContext)

interface LayoutProps {
  children: ReactNode
}

export default function Layout({ children }: LayoutProps) {
  const { theme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const [activeTab, setActiveTab] = useState("home")

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <NavContext.Provider value={{ activeTab, setActiveTab }}>
      <div className={`flex h-screen ${theme === "dark" ? "dark" : ""}`}>
        <Sidebar />
        <div className="w-full flex flex-1 flex-col">
          <header className="h-14 border-b border-gray-200 dark:border-white/[0.08]">
            <TopNav />
          </header>
          <main className="flex-1 overflow-auto p-6 bg-gray-50 dark:bg-black">{children}</main>
        </div>
      </div>
    </NavContext.Provider>
  )
}
