"use client"

import * as React from "react"
import { Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"

export function ThemeToggle() {
  const [mounted, setMounted] = React.useState(false)
  const { theme, setTheme } = useTheme()

  React.useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <button className="p-2 rounded-lg bg-white/5 border border-white/[0.08]">
        <div className="h-4 w-4" />
      </button>
    )
  }

  return (
    <button
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
      className="p-2 rounded-lg bg-white/5 hover:bg-white/10 border border-white/[0.08] transition-all duration-200"
    >
      {theme === "dark" ? (
        <Sun className="h-4 w-4 text-neutral-400 hover:text-white transition-colors" />
      ) : (
        <Moon className="h-4 w-4 text-neutral-400 hover:text-white transition-colors" />
      )}
      <span className="sr-only">Toggle theme</span>
    </button>
  )
}
